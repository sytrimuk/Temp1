import aiohttp
import asyncio
import json
import logging
logger = logging.getLogger(__name__)

class AsyncText2ImageAPI:
    def __init__(self, url, api_key, secret_key):
        self.URL = url
        self.AUTH_HEADERS = {
            'X-Key': f'Key {api_key}',
            'X-Secret': f'Secret {secret_key}',
        }

    async def get_model(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(f'{self.URL}key/api/v1/models', headers=self.AUTH_HEADERS) as response:
                data = await response.json()
                logger.info(f"Model data: {data}")
                return data[0]['id']

    async def generate(self, prompt, model, style, images=1, width=1536, height=1536):
        params = {
            "type": "GENERATE",
            "style": style,
            "numImages": images,
            "width": width,
            "height": height,
            "generateParams": {
                "query": f"{prompt}"
            }
        }

        form_data = aiohttp.FormData()
        form_data.add_field('model_id', str(model))
        form_data.add_field('params', json.dumps(params), content_type='application/json')

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f'{self.URL}key/api/v1/text2image/run',
                headers=self.AUTH_HEADERS,
                data=form_data
            ) as response:
                data = await response.json()
                logger.info(f"API Response: {data}")
                return data.get('uuid')

    async def check_generation(self, request_id, attempts=100, delay=15):
        while attempts > 0:
            async with aiohttp.ClientSession() as session:
                async with session.get(f'{self.URL}key/api/v1/text2image/status/{request_id}', headers=self.AUTH_HEADERS) as response:
                    data = await response.json()
                    if data['status'] == 'DONE':
                        return data['images']
            attempts -= 1
            await asyncio.sleep(delay)