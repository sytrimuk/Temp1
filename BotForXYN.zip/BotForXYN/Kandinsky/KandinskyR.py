import base64
import random
from aiogram import Router, F
from aiogram.types import Message, BufferedInputFile
import logging
from .KandinskyC import AsyncText2ImageAPI
import key_path

# Переменная для хранения бота
bot = None

def set_bot(bot_instance):
    global bot
    bot = bot_instance  # Передаем экземпляр бота в глобальную переменную

# Настраиваем логирование
logger = logging.getLogger(__name__)
STYLES = ['DEFAULT', 'UHD', 'ANIME', 'KANDINSKY']

# Создаем роутер для Kandinsky
kandinsky_router = Router()

@kandinsky_router.message(F.text.startswith("/kandinsky"))
async def generate_image(message: Message):
    try:
        # Извлекаем запрос пользователя из команды
        prompt = message.text[len("/kandinsky "):].strip()
        if not prompt:
            await message.answer("Введите запрос после команды /kandinsky.")
            return

        # Случайный стиль
        style = random.choice(STYLES)

        # Инициализируем API
        api = AsyncText2ImageAPI('https://api-key.fusionbrain.ai/', key_path.key, key_path.s_key)

        # Получаем модель
        model_id = await api.get_model()
        if not model_id:
            await message.answer("Ошибка: не удалось получить модель для генерации.")
            return

        # Генерация изображения
        uuid = await api.generate(prompt, model_id, style)
        if not uuid:
            await message.answer("Ошибка при отправке запроса на генерацию изображения.")
            return

        # Проверяем статус генерации и получаем изображения
        images = await api.check_generation(uuid)
        if not images:
            await message.answer("Не удалось получить сгенерированные изображения.")
            return

        for image_base64 in images:
            image_data = base64.b64decode(image_base64)

            # Подготавливаем картинку для отправки
            photo_file = BufferedInputFile(image_data, filename=f"{prompt}.png")

            # Отправляем картинку
            await message.answer_photo(photo=photo_file)

    except Exception as e:
        logger.error(f"Error in generate_image: {e}")
        await message.answer(f"Произошла ошибка при генерации изображения: {str(e)}")
