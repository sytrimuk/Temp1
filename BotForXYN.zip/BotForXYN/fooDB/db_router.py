from aiogram import Router, F
from aiogram.types import Message
from .db_manager import DatabaseManager
import key_path

db_router = Router()
db_manager = DatabaseManager(key_path.DB_PATH, key_path.CHAT_DB_NAME)

# Сначала регистрируем команды
@db_router.message(F.text.startswith("/countWord"))
async def get_top_words(message: Message):
    rows = db_manager.get_top_words()
    if rows:
        response = "Топ 10 самых популярных слов:\n" + "\n".join([f"{word}: {count}" for word, count in rows])
    else:
        response = "Слов пока нет в базе данных."
    await message.answer(response)

@db_router.message(F.text.startswith("/countWordMe"))
async def get_user_word_count(message: Message):
    username = message.from_user.username or "unknown_user"
    user_id = db_manager.get_user_id(username)
    count = db_manager.get_user_word_count(user_id)

    if count > 0:
        response = f"Вы написали {count} слов в чате."
    else:
        response = "Вы еще не написали ни одного слова."
    await message.answer(response)

@db_router.message(F.text.startswith("/countWordAll"))
async def get_total_word_count(message: Message):
    rows = db_manager.get_total_word_counts()
    if rows:
        response = "Общее количество слов по пользователям:\n" + "\n".join([f"{username}: {count}" for username, count in rows])
    else:
        response = "В чате пока нет активности."
    await message.answer(response)

# Затем регистрируем общий обработчик текстовых сообщений
@db_router.message(F.text & ~F.text.startswith("/"))
async def handle_text_message(message: Message):
    text = message.text.lower()
    words = text.split()
    username = message.from_user.username or "unknown_user"

    user_id = db_manager.get_user_id(username)

    for word in words:
        db_manager.update_word_count(word)

    db_manager.update_user_word_count(user_id, len(words))

    await message.answer(f"Обработано {len(words)} слов. Спасибо за сообщение!")
