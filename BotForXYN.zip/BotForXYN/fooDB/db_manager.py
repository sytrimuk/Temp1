import os
import sqlite3


class DatabaseManager:
    def __init__(self, db_path: str, db_name: str):
        self.db_full_path = os.path.join(db_path, db_name)

        # Создаем директорию для базы данных, если её нет
        if not os.path.exists(db_path):
            os.makedirs(db_path)

        # Инициализируем базу данных
        self._initialize_database()

    def _initialize_database(self):
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()

            # Создаем таблицы, если их ещё нет
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS CountWord (
                word TEXT PRIMARY KEY,
                count INTEGER DEFAULT 0
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS Users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE
            )
            """)

            cursor.execute("""
            CREATE TABLE IF NOT EXISTS UsersCountWord (
                user_id INTEGER,
                count INTEGER DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES Users(id)
            )
            """)

            conn.commit()

    def get_user_id(self, username: str) -> int:
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM Users WHERE username = ?", (username,))
            user_row = cursor.fetchone()

            if user_row:
                return user_row[0]

            cursor.execute("INSERT INTO Users (username) VALUES (?)", (username,))
            conn.commit()
            return cursor.lastrowid

    def update_word_count(self, word: str):
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()

            # Проверяем, существует ли слово в базе данных
            cursor.execute("SELECT count FROM CountWord WHERE word = ?", (word,))
            row = cursor.fetchone()

            if row:  # Если слово уже есть, увеличиваем счётчик
                cursor.execute("UPDATE CountWord SET count = count + 1 WHERE word = ?", (word,))
            else:  # Если слова нет, добавляем его
                cursor.execute("INSERT INTO CountWord (word, count) VALUES (?, ?)", (word, 1))

            conn.commit()


    def update_user_word_count(self, user_id: int, count: int):
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT count FROM UsersCountWord WHERE user_id = ?", (user_id,))
            if cursor.fetchone():
                cursor.execute("UPDATE UsersCountWord SET count = count + ? WHERE user_id = ?", (count, user_id))
            else:
                cursor.execute("INSERT INTO UsersCountWord (user_id, count) VALUES (?, ?)", (user_id, count))
            conn.commit()

    def get_top_words(self, limit: int = 10) -> list:
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()

            # Извлекаем слова с наибольшим количеством упоминаний
            cursor.execute("SELECT word, count FROM CountWord ORDER BY count DESC LIMIT ?", (limit,))
            rows = cursor.fetchall()

            return rows or []  # Возвращаем пустой список, если данные отсутствуют


    def get_user_word_count(self, user_id: int) -> int:
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT count FROM UsersCountWord WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            return row[0] if row else 0

    def get_total_word_counts(self) -> list:
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
            SELECT Users.username, UsersCountWord.count 
            FROM Users 
            INNER JOIN UsersCountWord ON Users.id = UsersCountWord.user_id
            ORDER BY UsersCountWord.count DESC
            """)
            return cursor.fetchall()
            
    def debug_print_all_words(self):
        with sqlite3.connect(self.db_full_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM CountWord")
            rows = cursor.fetchall()
            print("Все слова в базе данных:", rows)
