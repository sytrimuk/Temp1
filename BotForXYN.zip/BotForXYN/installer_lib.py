import subprocess
import sys

libraries = [
    "aiogram",       
    "aiohttp"
]

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

for lib in libraries:
    install(lib)

print("Все библиотеки успешно установлены!")