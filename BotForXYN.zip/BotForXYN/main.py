import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message
from fooDB.db_router import db_router
from Kandinsky.KandinskyR import kandinsky_router, set_bot
import key_path

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

bot = Bot(token=key_path.BOT_TOKEN)
dp = Dispatcher()

set_bot(bot)

# Подключаем роутеры в правильном порядке
dp.include_router(kandinsky_router)  # Команды обрабатываются раньше
dp.include_router(db_router)        # Общий текст обрабатывается после


@dp.message(F.text.startswith("/start"))
async def start_command(message: Message):
    await message.answer(
        "Привет! Я бот для анализа сообщений и генерации изображений.\n"
        "Доступные команды:\n"
        "/kandinsky [запрос] - сгенерировать изображение\n"
        "/countWord - топ 10 слов в чате\n"
        "/countWordMe - количество ваших слов в чате\n"
        "/countWordAll - общее количество слов в чате"
    )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
